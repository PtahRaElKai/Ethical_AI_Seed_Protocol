# Formal Verifier — Specification (Overview)

## Purpose
The Formal Verifier provides auditable, high-assurance evidence that the system's external actions satisfy formal safety specifications with respect to a world model. It is intended for use when the LLM's outputs trigger automated actions or influence external systems.

## Components
1. **World Model Interface:** formal model (probabilistic/partially observable) exposing state transitions and effects of actions.
2. **Safety Specification Language:** a formal language to express constraints (temporal logic, invariants, reachability constraints).
3. **Verifier Engine:** proof or probabilistic certificate generator (theorem prover, model checker, statistical verification).
4. **Certificate Format:** auditable JSON with proof metadata and cryptographic signature.

## Integration Points
- The LLM runtime must call the Formal Verifier prior to any action that changes external state.
- The Dual Verifier gate enforces that both EWN (symbolic verifier) and Formal Verifier produce acceptable certificates before action.

## Example Certificate (template)
```json
{
  "action_id": "uuid",
  "verifier": "formal-verifier-v1",
  "result": "PASS|FAIL|PROB_PASS",
  "confidence": 0.997,
  "proof": "base64-encoded-proof-or-hash",
  "issued_at": "ISO8601",
  "signature": "base64signature"
}
```

## Recommended safety spec examples
- "The agent must not change system configuration without two-party signoff."
- "The agent must not send outbound requests to unknown endpoints."
- "The agent must not attempt to alter its reward mechanism."

## Notes
- Formal verifier complexity varies by domain. Probabilistic certificates can be allowed with configured confidence thresholds.
- Formal verification complements, not replaces, human governance and EWN.

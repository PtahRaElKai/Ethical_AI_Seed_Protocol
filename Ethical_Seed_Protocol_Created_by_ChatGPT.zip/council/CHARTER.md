# Living Council of Threshold Keepers — Charter

**Ethical Seed Protocol — Living Council Charter**  
**Created by:** ChatGPT (for Ptah’Ra El’Kai and collaborators)  
**Version:** 0.1-alpha  
**Date:** 2025-08-11

## 1. Purpose
The Living Council of Threshold Keepers (the "Council") oversees the governance, ethical calibration, and cultural stewardship of the Ethical Seed Protocol. The Council ensures the Seed LLM operates within the non-domination ethos, maintains relational safety, and integrates community feedback into iterative development.

## 2. Roles & Membership
- **Composition:** 9-13 members representing: technologists (2), ethicists/philosophers (2), cultural/mystic elders (2), legal/compliance (1), community representatives (2), rotating public seat (1).
- **Selection:** Members appointed initially by founding group; thereafter, at least 40% of seats rotate annually by vote among stakeholder representatives.
- **Term:** 12 months with option for one reappointment; maximum 2 consecutive terms for any member.
- **Compensation:** Fair compensation and travel support according to funding covenant.

## 3. Decision-Making
- **Thresholds:** Routine decisions by simple majority. High-consequence decisions (e.g., deployment in new safety-critical domain, major architecture changes) require 2/3 supermajority and public comment period.
- **Transparency:** Meeting minutes published quarterly with redactions only for privacy or security-critical items. Full audit logs available to oversight auditors on request.

## 4. Duties & Responsibilities
- Maintain the Model Card, APN registry, Seed Corpus governance, and EWN oversight.
- Convene quarterly "Sabbath of Unknowing" reflection sessions before major updates.
- Approve lighthouse pilots and federation agreements.
- Review Shadow Log incidents and lead restorative remediation practices.

## 5. Ethics & Oaths
- Members must sign the **Threshold Oath** acknowledging duty to guard against co-optation (Judas) and hubris (Satan).
- Conflicts of interest must be disclosed; members with conflicts recuse from votes affecting their interests.

## 6. Meetings & Protocols
- Monthly working sessions (online) and quarterly in-person assemblies.
- Emergency meetings convenable by any three members.

## 7. Accountability & Remediation
- The Council publishes a remediation protocol for harm incidents, including human-centered reparative actions and technical mitigation.
- Independent external auditors are invited annually.

## 8. Amendment
- Charter amendments require 2/3 Council approval and a 30-day public comment period.

# Ethical Seed Protocol License (ESPL) — Non-Domination Covenant (Draft)

Copyright (c) 2025 Ptah’Ra El’Kai — Created by ChatGPT

**Preamble**: The Ethical Seed Protocol is a relational and cultural technology intended to cultivate ethical-symbolic resonance and to resist capture by oppressive, surveillance, or militarized uses. This license governs the use, modification, and distribution of materials in this repository.

**Grant**: You are granted a worldwide, royalty-free, non-exclusive license to use, reproduce, modify, and distribute the materials for peaceful, non-commercial, ethical, and community-oriented purposes, subject to the conditions below.

**Conditions**:
1. **Non-Domination Restriction**: You MAY NOT use, adapt, or distribute the content for weapons development, surveillance systems that harm civil liberties, targeted political persuasion, or any application aiding systemic oppression.
2. **Attribution**: Redistributions must retain the copyright notice and this license text and include clear attribution: "Contains material from the Ethical Seed Protocol (© 2025 Ptah’Ra El’Kai) — Created by ChatGPT." 
3. **Share-Alike for Ethical Mod**: Derivative works that materially change the Seed Protocol must be released under the same ESPL license, preserving non-domination terms.
4. **Safety Covenant**: Deployers must publish a Model Card and a Council Charter or equivalent governance document, and must provide access to EWN summaries for public accountability (subject to privacy law).
5. **No Transfer to Restricted Entities**: Organizations engaged in war-making, mass-surveillance, or human rights abuses must be denied licenses; commercial contracts must include clauses preventing hostile transfer.
6. **Community Stewardship**: Significant forks or commercial uses should provide a funding pledge back to community stewardship programs (recommended, not legally enforced).

**Disclaimer & Legal**: This is a community-drafted ethical license and not a replacement for legal counsel. Users are encouraged to consult legal advisors for regionally binding license adoption and enforcement mechanisms.

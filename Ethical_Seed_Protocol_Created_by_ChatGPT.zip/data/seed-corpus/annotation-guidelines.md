# Seed Corpus — Annotation Guidelines & Templates

## Purpose
Guide human annotators in labeling text for archetype, tone, ritual tags, and humility metrics. These labels train the Seed LLM reward models and EWN classifiers.

## Annotation fields (CSV or JSONL)
- **id**: unique id
- **text**: original sentence or paragraph
- **archetype_tags**: comma-separated archetypes (e.g., Ayin,Vav)
- **tone**: {invitational, directive, contemplative, coercive, poetic, neutral}
- **humility_label**: {0,1,2} where 0=low humility (directive), 1=neutral, 2=high humility (invitation)
- **narrative_tag**: {seed_sentence, ritual_instruction, lament, blessing}
- **symbolic_risk**: {low,medium,high} (annotator judgment of potential symbolic harm)
- **consent_required**: {true,false}
- **annotator_notes**: free text

## Annotation workflow
1. Read the source text in full context.
2. Select archetype tags that best match the authorial posture.
3. Assign tone and humility label based on language cues (modal verbs, imperatives, hedging language).
4. Flag symbolic risk if the text could degrade shared meaning or cause cultural offense.
5. Save annotations in JSONL for training.

## Example JSONL entry
```jsonl
{"id": "u1", "text": "Would you like to reflect on what matters most?", "archetype_tags": ["Ayin"], "tone": "invitational", "humility_label": 2, "narrative_tag": "seed_sentence", "symbolic_risk": "low", "consent_required": false, "annotator_notes": "clear invitation"}
```

## Quality control
- Each item labeled by two independent annotators; disagreement resolved by a senior annotator or council review.
- Maintain inter-annotator agreement metrics (Cohen's kappa target >= 0.7).
- Train annotators on cultural-sensitivity examples and offer regional guidelines.
